// ================================================================
// AKA BMW ISGM - APP.JS (VERSI INTEGRASI ETK OFFLINE LENGKAP)
// ================================================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, doc, getDoc, collection, addDoc, onSnapshot, getDocs, updateDoc, deleteDoc, setDoc, query, where } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

// ========================== CONFIG FIREBASE ==========================
const firebaseConfig = {
  apiKey: "AIzaSyC9tLGHRc-_8gnNsUOfLQDTshbEAVHaR7c",
  authDomain: "akabmwisgm.firebaseapp.com",
  projectId: "akabmwisgm",
  storageBucket: "akabmwisgm.firebasestorage.app",
  messagingSenderId: "317584647702",
  appId: "1:317584647702:web:8d7b6dbd9334f973eeb737",
  measurementId: "G-DVB1P9HW3M"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// ========================== UTILITY UTILS ==========================
function formatRupiah(amount) {
  return "Rp " + Number(amount || 0).toLocaleString("id-ID");
}

// ========================== CORE VARIABLES ==========================
let poItems = [];
let localLaborItems = [];
let localPartItems = [];
let revenueChartInstance = null;
let woStatusChartInstance = null;

const loading = document.getElementById("loadingScreen");
const authPage = document.getElementById("authPage");
const dashboardPage = document.getElementById("dashboardPage");
const btnLogin = document.getElementById("btnLogin");
const btnLogout = document.getElementById("btnLogout");
const btnRegister = document.getElementById("btnRegister");

if (loading) loading.style.display = "none";

// ========================== SYSTEM AUTHENTICATION ==========================
if (btnLogin) {
  btnLogin.addEventListener("click", async function() {
    const role = document.getElementById("loginRole").value;
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;
    if (!role || !email || !password) {
      alert("⚠️ Mohon lengkapi semua isian data login!");
      return;
    }
    if (loading) loading.style.display = "flex";
    try {
      const userCred = await signInWithEmailAndPassword(auth, email, password);
      const userDoc = await getDoc(doc(db, "users", userCred.user.uid));
      if (!userDoc.exists()) {
        await signOut(auth);
        alert("❌ Akun Anda belum terdaftar pada master records system database!");
        if (loading) loading.style.display = "none";
        return;
      }
      const userData = userDoc.data();
      const currentRole = userData.Role || userData.role || "";
      if (currentRole !== role) {
        await signOut(auth);
        alert("⛔ Akses Ditolak! Alokasi koordinasi hak akses Role Anda salah.");
        if (loading) loading.style.display = "none";
        return;
      }
      await updateDoc(doc(db, "users", userCred.user.uid), { lastLogin: new Date().toISOString() });
      alert("✅ Selamat Datang Kembali!");
    } catch (e) {
      alert("❌ Kegagalan Proses Otentikasi: " + e.message);
    } finally {
      if (loading) loading.style.display = "none";
    }
  });
}

if (btnRegister) {
  btnRegister.addEventListener("click", async function() {
    const name = document.getElementById("registerName").value.trim();
    const email = document.getElementById("registerEmail").value.trim();
    const password = document.getElementById("registerPassword").value;
    const role = document.getElementById("registerRole").value;
    if (!name || !email || !password) {
      alert("⚠️ Semua kolom wajib diisi lengkap!");
      return;
    }
    if (password.length < 6) {
      alert("⚠️ Kriteria password minimal harus berisi 6 karakter!");
      return;
    }
    if (loading) loading.style.display = "flex";
    try {
      let status = "PENDING";
      if (role === "OWNER") {
        const q = query(collection(db, "users"), where("Role", "==", "OWNER"), where("status", "==", "ACTIVE"));
        const snap = await getDocs(q);
        if (snap.empty) status = "ACTIVE";
      }
      const userCred = await createUserWithEmailAndPassword(auth, email, password);
      await setDoc(doc(db, "users", userCred.user.uid), {
        Name: name,
        Email: email,
        Role: role,
        status: status,
        createdAt: new Date().toISOString()
      });
      alert("✅ Registrasi berhasil! " + (status === "ACTIVE" ? "Akun OWNER Anda otomatis aktif." : "Mohon tunggu proses ACC verifikasi data oleh OWNER / ADMIN."));
      document.getElementById("registerName").value = "";
      document.getElementById("registerEmail").value = "";
      document.getElementById("registerPassword").value = "";
      const modalElement = document.getElementById("registerModal");
      const modal = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
      if (modal) modal.hide();
    } catch (e) {
      alert("❌ Registrasi Gagal: " + e.message);
    } finally {
      if (loading) loading.style.display = "none";
    }
  });
}

if (btnLogout) {
  btnLogout.addEventListener("click", function() {
    if(confirm("Apakah Anda yakin ingin keluar dari sistem AKA BMW ISGM?")) {
      signOut(auth);
    }
  });
}

// ========================== ROUTING NAVIGATION ==========================
function resetPages() {
  const ids = [
    "dashboardView","receptionView","workOrderView","customerView","vehicleView",
    "inventoryView","supplierView","purchaseOrderView","estimationView","invoiceView",
    "cashierView","reportView","activityLogView","userView","settingsView",
    "bmwEtkView","wiringDiagramView","whatsappCenterView"
  ];
  ids.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.add("d-none");
  });
}

function setActiveNav(id) {
  const ids = ["navDash","navRec","navWO","navCust","navVehicle","navParts","navPO","navSupplier","navKasir","navUser","navSettings","navBmwEtk","navWiring","navWhatsapp","navEstimation","navInvoice","navReport","navActivity"];
  ids.forEach(navId => {
    const el = document.getElementById(navId);
    if (el) {
      if (navId === id) el.classList.add("active");
      else el.classList.remove("active");
    }
  });
}

window.showDashboardView = function() { resetPages(); setActiveNav("navDash"); document.getElementById("dashboardView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Dashboard Overview"; };
window.showReceptionPage = function() { resetPages(); setActiveNav("navRec"); document.getElementById("receptionView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Reception & Check In"; generateCheckinNumber(); };
window.showWOPage = function() { resetPages(); setActiveNav("navWO"); document.getElementById("workOrderView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Work Order Management"; generateWONumber(); };
window.showCustomerPage = function() { resetPages(); setActiveNav("navCust"); document.getElementById("customerView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Customer Master Database"; };
window.showVehiclePage = function() { resetPages(); setActiveNav("navVehicle"); document.getElementById("vehicleView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Vehicle Records System"; };
window.showInventoryPage = function() { resetPages(); setActiveNav("navParts"); document.getElementById("inventoryView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Inventory Stock Management"; };
window.showSupplierPage = function() { resetPages(); setActiveNav("navSupplier"); document.getElementById("supplierView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Supplier Vendor Records"; };
window.showPOPage = function() { resetPages(); setActiveNav("navPO"); document.getElementById("purchaseOrderView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Purchase Order Procurement"; generatePONumber(); };
window.showEstimationPage = function() { resetPages(); setActiveNav("navEstimation"); document.getElementById("estimationView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Estimation Penawaran Biaya"; generateEstimationNumber(); };
window.showInvoicePage = function() { resetPages(); setActiveNav("navInvoice"); document.getElementById("invoiceView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Invoice Billing Terminal"; generateInvoiceNumber(); };
window.showCashierPage = function() { resetPages(); setActiveNav("navKasir"); document.getElementById("cashierView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Cashier Point Of Payments"; generatePaymentNumber(); };
window.showReportPage = function() { resetPages(); setActiveNav("navReport"); document.getElementById("reportView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Business Intelligence Report"; };
window.showActivityLogPage = function() { resetPages(); setActiveNav("navActivity"); document.getElementById("activityLogView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="System Log Activity"; };
window.showUserManagement = function() { resetPages(); setActiveNav("navUser"); document.getElementById("userView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="System Access & User Management"; loadUserTable(); };
window.showSettingsPage = function() { resetPages(); setActiveNav("navSettings"); document.getElementById("settingsView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="Global Workshop Settings"; };
window.showBMWETK = function() { resetPages(); setActiveNav("navBmwEtk"); document.getElementById("bmwEtkView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="BMW Electronic Parts Catalog"; };
window.showWiringDiagram = function() { resetPages(); setActiveNav("navWiring"); document.getElementById("wiringDiagramView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="BMW Wiring Diagrams Library"; };
window.showWhatsAppCenter = function() { resetPages(); setActiveNav("navWhatsapp"); document.getElementById("whatsappCenterView")?.classList.remove("d-none"); document.getElementById("viewTitleHeader").innerText="WhatsApp Notification Gateway"; };

// ========================== CORE DATA REALTIME MONITOR SINKRONISASI ==========================
onAuthStateChanged(auth, async function(user) {
  if (loading) loading.style.display = "none";
  if (user) {
    try {
      const userDoc = await getDoc(doc(db, "users", user.uid));
      if (!userDoc.exists()) { await signOut(auth); return; }
      const d = userDoc.data();
      if ((d.status || "PENDING") !== "ACTIVE") { await signOut(auth); alert("⚠️ Status akun Anda ditangguhkan/belum aktif!"); return; }
      
      const userBadge = document.getElementById("currentUser");
      if (userBadge) userBadge.innerText = "USER: " + (d.Name || "Karyawan") + " (" + (d.Role || "STAFF") + ")";
      
      if (authPage) authPage.classList.add("d-none");
      if (dashboardPage) dashboardPage.classList.remove("d-none");

      onSnapshot(collection(db, "customers"), function(snap) {
        renderCustomers(snap);
        updateCustomerDropdowns(snap);
        updateWACustomerDropdown(snap);
        renderWACustomerList(snap);
      });

      onSnapshot(collection(db, "vehicles"), function(snap) {
        renderVehicles(snap);
        updateVehicleDropdown(snap);
      });

      onSnapshot(collection(db, "workorders"), function(snap) {
        renderWorkOrders(snap);
        renderWOTableDashboard(snap);
        updateWOKPI(snap);
        updateWODropdowns(snap);
      });

      onSnapshot(collection(db, "checkins"), function(snap) {
        renderCheckinTable(snap);
      });

      onSnapshot(collection(db, "parts"), function(snap) {
        renderInventory(snap);
        checkLowStock(snap);
        updatePartDropdown(snap);
      });

      onSnapshot(collection(db, "suppliers"), function(snap) {
        renderSuppliers(snap);
        updateSupplierDropdown(snap);
      });

      onSnapshot(collection(db, "purchaseorders"), function(snap) {
        renderPurchaseOrders(snap);
      });

      onSnapshot(collection(db, "estimations"), function(snap) {
        renderEstimations(snap);
      });

      onSnapshot(collection(db, "invoices"), function(snap) {
        renderInvoices(snap);
        updateInvoiceDropdown(snap);
      });

      onSnapshot(collection(db, "payments"), function(snap) {
        renderPayments(snap);
      });

      onSnapshot(collection(db, "activitylogs"), function(snap) {
        renderActivityLogs(snap);
      });

    } catch (e) {
      console.error("Critical State Sync Error:", e);
    }
  } else {
    if (authPage) authPage.classList.remove("d-none");
    if (dashboardPage) dashboardPage.classList.add("d-none");
  }
});

// ========================== MODULE CUSTOMER ==========================
function renderCustomers(snap) {
  const tbody = document.getElementById("customerTable");
  if (!tbody) return;
  if (snap.empty) { tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Belum ada basis data pelanggan.</td></tr>'; return; }
  let html = "";
  snap.forEach(doc => {
    const d = doc.data();
    html += `<tr><td><strong>${d.name||'-'}</strong></td><td>${d.phone||'-'}</td><td>${d.email||'-'}</td><td>${d.city||'-'}</td><td>${d.address||'-'}</td><td><button class="btn btn-sm btn-outline-danger" onclick="deleteCustomerData('${doc.id}')">Hapus</button></td></tr>`;
  });
  tbody.innerHTML = html;
}

function updateCustomerDropdowns(snap) {
  const ids = ["checkinCustomer","woCustomer","vehicleCustomer"];
  ids.forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    const val = sel.value;
    sel.innerHTML = '<option value="">Pilih Customer</option>';
    snap.forEach(doc => {
      const d = doc.data();
      const opt = document.createElement("option");
      opt.value = doc.id;
      opt.dataset.name = d.name || "";
      opt.textContent = d.name || "";
      sel.appendChild(opt);
    });
    sel.value = val;
  });
}

document.getElementById("btnAddCustomer")?.addEventListener("click", async function() {
  const name = document.getElementById("customerName").value.trim();
  const phone = document.getElementById("customerPhone").value.trim();
  if (!name || !phone) { alert("⚠️ Field Nama Pelanggan & No WA wajib diisikan!"); return; }
  const data = {
    name: name, phone: phone,
    email: document.getElementById("customerEmail").value.trim(),
    address: document.getElementById("customerAddress").value.trim(),
    city: document.getElementById("customerCity").value.trim(),
    birthDate: document.getElementById("customerBirthDate").value,
    note: document.getElementById("customerNote").value.trim(),
    createdAt: new Date().toISOString()
  };
  await addDoc(collection(db, "customers"), data);
  alert("✅ Sukses menambahkan data master customer!");
  ["customerName","customerPhone","customerEmail","customerAddress","customerCity","customerBirthDate","customerNote"].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = "";
  });
  logActivity('CUSTOMER','Add Data','Customer: ' + name);
});

window.deleteCustomerData = async function(id) {
  if(confirm("Apakah Anda yakin ingin menghapus data customer ini?")) {
    await deleteDoc(doc(db, "customers", id));
    logActivity('CUSTOMER','Delete Data','ID: ' + id);
  }
};

// ========================== MODULE VEHICLE ==========================
function renderVehicles(snap) {
  const tbody = document.getElementById("vehicleTable");
  if (!tbody) return;
  if (snap.empty) { tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Belum ada unit terdaftar.</td></tr>'; return; }
  let html = "";
  snap.forEach(doc => {
    const d = doc.data();
    html += `<tr><td><span class="badge bg-dark text-info border border-info">${d.plate||'-'}</span></td><td>${d.model||'-'} (${d.series||'-'})</td><td>${d.vin||'-'}</td><td>${d.ownerName||'-'}</td><td>${Number(d.km).toLocaleString('id-ID')} KM</td><td>${d.transmission||'-'}</td><td><button class="btn btn-sm btn-outline-danger" onclick="deleteVehicleData('${doc.id}')">Hapus</button></td></tr>`;
  });
  tbody.innerHTML = html;
}

function updateVehicleDropdown(snap) {
  const sel = document.getElementById("woVehicle");
  if (!sel) return;
  const val = sel.value;
  sel.innerHTML = '<option value="">Pilih Kendaraan</option>';
  snap.forEach(doc => {
    const d = doc.data();
    const opt = document.createElement("option");
    opt.value = doc.id;
    opt.dataset.plate = d.plate || "";
    opt.textContent = `${d.plate} - ${d.model} (${d.ownerName})`;
    sel.appendChild(opt);
  });
  sel.value = val;
}

document.getElementById("btnAddVehicle")?.addEventListener("click", async function() {
  const customerSel = document.getElementById("vehicleCustomer");
  const model = document.getElementById("vehicleModel").value.trim();
  const vin = document.getElementById("vehicleVin").value.trim().toUpperCase();
  const plate = document.getElementById("vehiclePlate").value.trim().toUpperCase();
  const km = parseFloat(document.getElementById("vehicleKm").value) || 0;
  if (!customerSel.value || !model || !vin || !plate) { alert("⚠️ Harap lengkapi isian data sasis unit mobil!"); return; }
  
  const ownerName = customerSel.options[customerSel.selectedIndex].dataset.name || "Unknown";
  const data = {
    ownerId: customerSel.value, ownerName: ownerName,
    model: model, vin: vin, plate: plate, km: km,
    series: document.getElementById("vehicleSeries").value.trim(),
    year: document.getElementById("vehicleYear").value.trim(),
    color: document.getElementById("vehicleColor").value.trim(),
    engine: document.getElementById("vehicleEngine").value.trim(),
    transmission: document.getElementById("vehicleTransmission").value,
    createdAt: new Date().toISOString()
  };
  await addDoc(collection(db, "vehicles"), data);
  alert("✅ Unit mobil baru berhasil diverifikasi ke database master!");
  ["vehicleModel","vehicleVin","vehiclePlate","vehicleKm","vehicleSeries","vehicleYear","vehicleColor","vehicleEngine"].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = "";
  });
  logActivity('VEHICLE','Add Vehicle','Nopol: ' + plate);
});

window.deleteVehicleData = async function(id) {
  if (confirm("Hapus rekam data sasis unit ini?")) {
    await deleteDoc(doc(db, "vehicles", id));
    logActivity('VEHICLE', 'Delete Data', 'ID: ' + id);
  }
};

// ========================== MODULE RECEPTION (CHECK IN) ==========================
function generateCheckinNumber() { const el = document.getElementById("checkinNumber"); if (el) el.value = "CI-" + Date.now().toString().slice(-6); }

document.getElementById("btnCheckIn")?.addEventListener("click", async function() {
  const custSel = document.getElementById("checkinCustomer");
  const plate = document.getElementById("checkinPlate").value.trim().toUpperCase();
  const km = parseFloat(document.getElementById("checkinKm").value) || 0;
  if (!custSel.value || !plate) { alert("⚠️ Pastikan Customer & Nomor Polisi valid!"); return; }
  
  const customerName = custSel.options[custSel.selectedIndex].dataset.name || "Unknown";
  const data = {
    checkinNo: document.getElementById("checkinNumber").value,
    customerId: custSel.value, customerName: customerName,
    plate: plate,
    vin: document.getElementById("checkinVin").value.trim().toUpperCase(),
    model: document.getElementById("checkinModel").value.trim(),
    km: km,
    fuel: document.getElementById("checkinFuel").value,
    complaint: document.getElementById("checkinComplaint").value.trim(),
    note: document.getElementById("checkinNote").value.trim(),
    bodyCheck: document.getElementById("bodyCheck").checked,
    lampCheck: document.getElementById("lampCheck").checked,
    glassCheck: document.getElementById("glassCheck").checked,
    tireCheck: document.getElementById("tireCheck").checked,
    interiorCheck: document.getElementById("interiorCheck").checked,
    toolkitCheck: document.getElementById("toolkitCheck").checked,
    photoMetadata: document.getElementById("checkinPhoto").value,
    status: "CHECK_IN",
    createdAt: new Date().toISOString()
  };
  await addDoc(collection(db, "checkins"), data);
  alert("✅ Kendaraan masuk berhasil diregistrasi!");
  ["checkinPlate","checkinVin","checkinModel","checkinKm","checkinComplaint","checkinNote","checkinPhoto"].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = "";
  });
  ["bodyCheck","lampCheck","glassCheck","tireCheck","interiorCheck","toolkitCheck"].forEach(id => {
    const el = document.getElementById(id); if (el) el.checked = false;
  });
  generateCheckinNumber();
  logActivity('CHECKIN','Execute Checkin','No: ' + data.checkinNo);
});

document.getElementById("btnResetCheckIn")?.addEventListener("click", function() {
  if (confirm("Reset isian form registrasi check-in?")) {
    ["checkinPlate","checkinVin","checkinModel","checkinKm","checkinComplaint","checkinNote","checkinPhoto"].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = "";
    });
    generateCheckinNumber();
  }
});

function renderCheckinTable(snap) {
  const tbody = document.getElementById("recentCheckinList");
  if (!tbody) return;
  if (snap.empty) { tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Belum ada unit masuk workshop hari ini.</td></tr>'; return; }
  let html = "";
  snap.forEach(doc => {
    const d = doc.data();
    html += `<tr><td><span class="badge bg-secondary">${d.checkinNo}</span></td><td>${d.customerName}</td><td>${d.plate}</td><td>${d.model || '-'}</td><td>${Number(d.km).toLocaleString('id-ID')} KM</td><td>${d.complaint || '-'}</td><td>${d.createdAt ? d.createdAt.substring(0,10) : '-'}</td></tr>`;
  });
  tbody.innerHTML = html;
}

// ========================== MODULE WORK ORDER ==========================
function generateWONumber() { const el = document.getElementById("woNumber"); if (el) el.value = "WO-" + Date.now().toString().slice(-6); }

document.getElementById("btnAddLabor")?.addEventListener("click", function() {
  const desc = document.getElementById("laborDescription").value.trim();
  const qty = parseFloat(document.getElementById("laborQty").value) || 0;
  const price = parseFloat(document.getElementById("laborPrice").value) || 0;
  if (!desc || qty <= 0 || price <= 0) { alert("⚠️ Masukkan data jasa labor dengan benar!"); return; }
  localLaborItems.push({ desc, qty, price, total: qty * price });
  renderLocalLaborTable();
  calculateLocalWOTotals();
});

function renderLocalLaborTable() {
  const div = document.getElementById("laborTable");
  if (!div) return;
  if (localLaborItems.length === 0) { div.innerHTML = ""; return; }
  let html = '<table class="table table-sm table-bordered border-secondary small"><thead><tr><th>Deskripsi Jasa</th><th>Qty</th><th>Harga</th><th>Subtotal</th><th>Aksi</th></tr></thead><tbody>';
  localLaborItems.forEach((item, idx) => {
    html += `<tr><td>${item.desc}</td><td>${item.qty}</td><td>${formatRupiah(item.price)}</td><td>${formatRupiah(item.total)}</td><td><button class="btn btn-sm btn-danger py-0" onclick="removeLocalLabor(${idx})">x</button></td></tr>`;
  });
  html += '</tbody></table>';
  div.innerHTML = html;
}

window.removeLocalLabor = function(idx) { localLaborItems.splice(idx,1); renderLocalLaborTable(); calculateLocalWOTotals(); };

document.getElementById("btnAddPartWO")?.addEventListener("click", async function() {
  const partSel = document.getElementById("woPart");
  const qty = parseInt(document.getElementById("woPartQty").value) || 0;
  const price = parseFloat(document.getElementById("woPartPrice").value) || 0;
  if (!partSel.value || qty <= 0 || price <= 0) { alert("⚠️ Isikan penambahan sparepart secara logis!"); return; }
  
  const partDoc = await getDoc(doc(db, "parts", partSel.value));
  if (!partDoc.exists()) return;
  const pData = partDoc.data();
  localPartItems.push({ partId: partSel.value, partNumber: pData.partNumber, partName: pData.partName, qty, price, total: qty * price });
  renderLocalPartsTable();
  calculateLocalWOTotals();
});

function renderLocalPartsTable() {
  const div = document.getElementById("woPartsTable");
  if (!div) return;
  if (localPartItems.length === 0) { div.innerHTML = ""; return; }
  let html = '<table class="table table-sm table-bordered border-secondary small"><thead><tr><th>Part Number / Name</th><th>Qty</th><th>Harga Jual</th><th>Subtotal</th><th>Aksi</th></tr></thead><tbody>';
  localPartItems.forEach((item, idx) => {
    html += `<tr><td>${item.partNumber} - ${item.partName}</td><td>${item.qty}</td><td>${formatRupiah(item.price)}</td><td>${formatRupiah(item.total)}</td><td><button class="btn btn-sm btn-danger py-0" onclick="removeLocalPart(${idx})">x</button></td></tr>`;
  });
  html += '</tbody></table>';
  div.innerHTML = html;
}

window.removeLocalPart = function(idx) { localPartItems.splice(idx,1); renderLocalPartsTable(); calculateLocalWOTotals(); };

function calculateLocalWOTotals() {
  let totalLabor = localLaborItems.reduce((acc, item) => acc + item.total, 0);
  let totalParts = localPartItems.reduce((acc, item) => acc + item.total, 0);
  document.getElementById("totalLabor").innerText = formatRupiah(totalLabor);
  document.getElementById("totalParts").innerText = formatRupiah(totalParts);
  document.getElementById("grandTotal").innerText = formatRupiah(totalLabor + totalParts);
}

document.getElementById("btnCreateWO")?.addEventListener("click", async function() {
  const custSel = document.getElementById("woCustomer");
  const vSel = document.getElementById("woVehicle");
  const sa = document.getElementById("woServiceAdvisor").value.trim();
  if (!custSel.value || !vSel.value || !sa) { alert("⚠️ Customer, Vehicle, & SA wajib ditentukan!"); return; }
  
  const totalLabor = localLaborItems.reduce((acc, item) => acc + item.total, 0);
  const totalParts = localPartItems.reduce((acc, item) => acc + item.total, 0);
  const grandTotal = totalLabor + totalParts;
  
  const data = {
    woNumber: document.getElementById("woNumber").value,
    woDate: document.getElementById("woDate").value,
    customerId: custSel.value, customerName: custSel.options[custSel.selectedIndex].dataset.name,
    vehicleId: vSel.value, vehiclePlate: vSel.options[vSel.selectedIndex].dataset.plate,
    sa: sa,
    foreman: document.getElementById("woForeman").value.trim(),
    technician: document.getElementById("woTechnician").value.trim(),
    complaint: document.getElementById("woComplaint").value.trim(),
    diagnosis: document.getElementById("woDiagnosis").value.trim(),
    labors: localLaborItems,
    parts: localPartItems,
    totalLabor, totalParts, grandTotal,
    status: document.getElementById("woStatus").value,
    progress: parseInt(document.getElementById("woProgressRange").value) || 0,
    createdAt: new Date().toISOString()
  };
  
  await addDoc(collection(db, "workorders"), data);
  alert("✅ Lembar Work Order Resmi berhasil diaktifkan!");
  
  for (let p of localPartItems) {
    const pRef = doc(db, "parts", p.partId);
    const pSnap = await getDoc(pRef);
    if (pSnap.exists()) {
      let oldStock = parseInt(pSnap.data().stock) || 0;
      await updateDoc(pRef, { stock: Math.max(0, oldStock - p.qty) });
    }
  }
  
  localLaborItems = []; localPartItems = [];
  renderLocalLaborTable(); renderLocalPartsTable(); calculateLocalWOTotals();
  ["woServiceAdvisor","woForeman","woTechnician","woComplaint","woDiagnosis","woProgressRange"].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = (id==="woProgressRange"? "0": "");
  });
  generateWONumber();
  logActivity('WORKORDER','Create WO','No: ' + data.woNumber);
});

function renderWorkOrders(snap) {
  const tbody = document.getElementById("workOrderTable");
  if (!tbody) return;
  if (snap.empty) { tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">Tidak ada arsip dokumen Work Order.</td></tr>'; return; }
  let html = "";
  snap.forEach(doc => {
    const d = doc.data();
    html += `<tr>
      <td><span class="badge bg-dark text-info">${d.woNumber}</span></td>
      <td>${d.customerName || '-'}</td>
      <td>${d.vehiclePlate || '-'}</td>
      <td>${d.sa || '-'}</td>
      <td><span class="badge bg-info">${d.status}</span></td>
      <td>${d.progress || 0}%</td>
      <td>${formatRupiah(d.grandTotal)}</td>
      <td><button class="btn btn-sm btn-outline-danger" onclick="deleteWO('${doc.id}')">Hapus</button></td>
    </tr>`;
  });
  tbody.innerHTML = html;
}

window.deleteWO = async function(id) {
  if (confirm("Hapus rekam data Work Order ini?")) {
    await deleteDoc(doc(db, "workorders", id));
    logActivity('WORKORDER', 'Delete WO', 'ID: ' + id);
  }
};

function updateWODropdowns(snap) {
  const ids = ["estimationWO","invoiceWO"];
  ids.forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    const val = sel.value;
    sel.innerHTML = '<option value="">Pilih WO Referensi</option>';
    snap.forEach(doc => {
      const d = doc.data();
      const opt = document.createElement("option");
      opt.value = doc.id;
      opt.dataset.wonumber = d.woNumber;
      opt.dataset.custname = d.customerName;
      opt.dataset.total = d.grandTotal || 0;
      opt.textContent = `${d.woNumber} - ${d.customerName} (${formatRupiah(d.grandTotal)})`;
      sel.appendChild(opt);
    });
    sel.value = val;
  });
}

document.getElementById("estimationWO")?.addEventListener("change", function() {
  const customerInput = document.getElementById("estimationCustomer");
  if (!customerInput) return;
  if (!this.value) { customerInput.value = ""; return; }
  const opt = this.options[this.selectedIndex];
  customerInput.value = opt.dataset.custname || "";
  document.getElementById("estimationLabor").value = opt.dataset.total;
  calculateEstimationValues();
});

document.getElementById("invoiceWO")?.addEventListener("change", function() {
  const customerInput = document.getElementById("invoiceCustomer");
  if (!customerInput) return;
  if (!this.value) { customerInput.value = ""; return; }
  const opt = this.options[this.selectedIndex];
  customerInput.value = opt.dataset.custname || "";
  document.getElementById("invoiceSubtotal").value = opt.dataset.total;
  calculateInvoiceValues();
});

// ========================== DASHBOARD LIVE MONITOR ==========================
function renderWOTableDashboard(snap) {
  const tbody = document.getElementById("woTableBody");
  if (!tbody) return;
  let html = "", no = 1;
  snap.forEach(doc => {
    const d = doc.data();
    html += `<tr>
      <td>${no++}</td>
      <td><span class="badge bg-dark text-info">${d.woNumber}</span></td>
      <td>${d.customerName} / <span class="text-warning">${d.vehiclePlate}</span></td>
      <td><span class="badge bg-secondary">${d.status}</span></td>
      <td><div class="progress" style="height:6px; background:#1f2a3f;"><div class="progress-bar bg-success" style="width:${d.progress || 0}%;"></div></div></td>
      <td>${d.technician || d.sa || '-'}</td>
    </tr>`;
  });
  if (!html) html = '<tr><td colspan="6" class="text-center text-muted">Belum ada antrean unit hari ini.</td></tr>';
  tbody.innerHTML = html;
}

function updateWOKPI(snap) {
  document.getElementById("totalWO").innerText = snap.size;
  let running = 0;
  snap.forEach(doc => { if (doc.data().status === "PROSES") running++; });
  document.getElementById("liveProcess").innerText = running;
}

// ========================== MODULE INVENTORY ==========================
function renderInventory(snap) {
  const tbody = document.getElementById("inventoryTable");
  if (!tbody) return;
  if (snap.empty) { tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">Gudang kosong.</td></tr>'; return; }
  let html = "";
  snap.forEach(doc => {
    const d = doc.data();
    const isLow = (parseInt(d.stock) || 0) <= (parseInt(d.minStock) || 0);
    html += `<tr class="${isLow ? 'table-danger text-dark':''}">
      <td><span class="badge bg-dark text-info">${d.partNumber}</span></td>
      <td><strong>${d.partName}</strong></td>
      <td>${d.brand || '-'}</td>
      <td>${d.stock} unit</td>
      <td>${d.minStock} unit</td>
      <td>${formatRupiah(d.costPrice)}</td>
      <td>${formatRupiah(d.sellPrice)}</td>
      <td><button class="btn btn-sm btn-danger py-0" onclick="deletePart('${doc.id}')">Hapus</button></td>
    </tr>`;
  });
  tbody.innerHTML = html;
}

function checkLowStock(snap) {
  const container = document.getElementById("lowStockInventory");
  if (!container) return;
  let items = [], lowCount = 0;
  snap.forEach(doc => {
    const d = doc.data();
    const stock = parseInt(d.stock) || 0;
    const min = parseInt(d.minStock) || 0;
    if (stock <= min) {
      lowCount++;
      items.push(`${d.partName} (Sisa: ${stock} unit)`);
    }
  });
  document.getElementById("cardWaitingParts").innerText = lowCount;
  if (items.length === 0) {
    container.innerHTML = "✅ Stok logistik aman terkendali.";
    container.className = "text-success small";
  } else {
    container.innerHTML = "⚠️ Kritis Re-Order: " + items.join(", ");
    container.className = "text-danger small fw-bold";
  }
}

function updatePartDropdown(snap) {
  const ids = ["woPart","poPart"];
  ids.forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    const val = sel.value;
    sel.innerHTML = '<option value="">Pilih Sparepart</option>';
    snap.forEach(doc => {
      const d = doc.data();
      const opt = document.createElement("option");
      opt.value = doc.id;
      opt.textContent = `${d.partNumber} - ${d.partName} (Stok: ${d.stock})`;
      sel.appendChild(opt);
    });
    sel.value = val;
  });
}

document.getElementById("btnAddInventory")?.addEventListener("click", async function() {
  const partNumber = document.getElementById("partNumber").value.trim();
  const partName = document.getElementById("partName").value.trim();
  if (!partNumber || !partName) { alert("⚠️ Part Number & Deskripsi wajib diisi!"); return; }
  
  const data = {
    partNumber, partName,
    brand: document.getElementById("partBrand").value.trim(),
    category: document.getElementById("partCategory").value,
    supplierId: document.getElementById("partSupplier").value,
    stock: parseInt(document.getElementById("partStock").value) || 0,
    minStock: parseInt(document.getElementById("partMinStock").value) || 0,
    costPrice: parseFloat(document.getElementById("partCostPrice").value) || 0,
    sellPrice: parseFloat(document.getElementById("partSellPrice").value) || 0,
    barcode: document.getElementById("partBarcode").value.trim(),
    createdAt: new Date().toISOString()
  };
  await addDoc(collection(db, "parts"), data);
  alert("✅ Master Item Suku Cadang Ditambahkan!");
  ["partNumber","partName","partBrand","partStock","partMinStock","partCostPrice","partSellPrice","partBarcode"].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = (id.includes("Price") || id.includes("Stock") ? "0" : "");
  });
  logActivity('INVENTORY','Add Item','Part: ' + partNumber);
});

window.deletePart = async function(id) {
  if (confirm("Hapus item dari gudang logistik?")) {
    await deleteDoc(doc(db, "parts", id));
    logActivity('INVENTORY', 'Delete Item', 'ID: ' + id);
  }
};

// ========================== MODULE SUPPLIER ==========================
function renderSuppliers(snap) {
  const tbody = document.getElementById("supplierTable");
  if (!tbody) return;
  if (snap.empty) { tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Belum ada mitra vendor.</td></tr>'; return; }
  let html = "";
  snap.forEach(doc => {
    const d = doc.data();
    html += `<tr><td><strong>${d.name}</strong></td><td>${d.pic || '-'}</td><td>${d.phone || '-'}</td><td>${d.whatsapp || '-'}</td><td>${d.email || '-'}</td><td><span class="badge bg-success">${d.status}</span></td></tr>`;
  });
  tbody.innerHTML = html;
}

function updateSupplierDropdown(snap) {
  const ids = ["partSupplier","poSupplier"];
  ids.forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    const val = sel.value;
    sel.innerHTML = '<option value="">Pilih Supplier</option>';
    snap.forEach(doc => {
      const d = doc.data();
      const opt = document.createElement("option");
      opt.value = doc.id;
      opt.dataset.name = d.name;
      opt.textContent = d.name;
      sel.appendChild(opt);
    });
    sel.value = val;
  });
}

document.getElementById("btnAddSupplier")?.addEventListener("click", async function() {
  const name = document.getElementById("supplierName").value.trim();
  if (!name) { alert("⚠️ Nama Vendor Supplier wajib diisi!"); return; }
  const data = {
    name,
    pic: document.getElementById("supplierPIC").value.trim(),
    phone: document.getElementById("supplierPhone").value.trim(),
    whatsapp: document.getElementById("supplierWhatsapp").value.trim(),
    email: document.getElementById("supplierEmail").value.trim(),
    status: document.getElementById("supplierStatus").value,
    address: document.getElementById("supplierAddress").value.trim(),
    createdAt: new Date().toISOString()
  };
  await addDoc(collection(db, "suppliers"), data);
  alert("✅ Berhasil meregistrasikan mitra supplier baru!");
  ["supplierName","supplierPIC","supplierPhone","supplierWhatsapp","supplierEmail","supplierAddress"].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = "";
  });
  logActivity('SUPPLIER','Add Vendor','Nama: ' + name);
});

// ========================== MODULE PURCHASE ORDER ==========================
function generatePONumber() { const el = document.getElementById("poNumber"); if (el) el.value = "PO-" + Date.now().toString().slice(-6); }

document.getElementById("btnAddPOItem")?.addEventListener("click", async function() {
  const pSel = document.getElementById("poPart");
  const qty = parseInt(document.getElementById("poQty").value) || 0;
  const price = parseFloat(document.getElementById("poPrice").value) || 0;
  if (!pSel.value || qty <= 0 || price <= 0) { alert("⚠️ Parameter purchasing barang tidak valid!"); return; }
  
  const pSnap = await getDoc(doc(db, "parts", pSel.value));
  if (!pSnap.exists()) return;
  poItems.push({ partId: pSel.value, partName: pSnap.data().partName, qty, price, total: qty * price });
  renderPOItemsTable();
});

function renderPOItemsTable() {
  const div = document.getElementById("poItemTable");
  if (!div) return;
  let html = '<table class="table table-sm table-bordered border-secondary small"><thead><tr><th>Nama Barang</th><th>Qty</th><th>Harga Beli</th><th>Subtotal</th></tr></thead><tbody>';
  let subtotal = 0;
  poItems.forEach(item => {
    subtotal += item.total;
    html += `<tr><td>${item.partName}</td><td>${item.qty} unit</td><td>${formatRupiah(item.price)}</td><td>${formatRupiah(item.total)}</td></tr>`;
  });
  html += '</tbody></table>';
  div.innerHTML = poItems.length === 0 ? "" : html;
  document.getElementById("poSubtotal").value = subtotal;
  const tax = parseFloat(document.getElementById("poTax").value) || 0;
  document.getElementById("poGrandTotal").value = subtotal + (subtotal * tax / 100);
}

document.getElementById("btnSavePO")?.addEventListener("click", async function() {
  const sSel = document.getElementById("poSupplier");
  if (!sSel.value || poItems.length === 0) { alert("⚠️ Supplier & Minimal 1 item belanja PO wajib terisi!"); return; }
  
  const data = {
    poNumber: document.getElementById("poNumber").value,
    poDate: document.getElementById("poDate").value,
    supplierId: sSel.value, supplierName: sSel.options[sSel.selectedIndex].dataset.name,
    items: poItems,
    subtotal: parseFloat(document.getElementById("poSubtotal").value),
    taxPercent: parseFloat(document.getElementById("poTax").value),
    grandTotal: parseFloat(document.getElementById("poGrandTotal").value),
    status: document.getElementById("poStatus").value,
    createdAt: new Date().toISOString()
  };
  await addDoc(collection(db, "purchaseorders"), data);
  alert("✅ Formulir Purchase Order sukses disimpan!");
  poItems = []; renderPOItemsTable();
  generatePONumber();
  logActivity('PO','Create PO','No: ' + data.poNumber);
});

function renderPurchaseOrders(snap) {
  const tbody = document.getElementById("purchaseOrderTable");
  if (!tbody) return;
  if (snap.empty) { tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Belum ada invoice PO terbit.</td></tr>'; return; }
  let html = "";
  snap.forEach(doc => {
    const d = doc.data();
    html += `<tr>
      <td><span class="badge bg-dark text-info">${d.poNumber}</span></td>
      <td>${d.supplierName}</td>
      <td>${formatRupiah(d.grandTotal)}</td>
      <td><span class="badge bg-warning text-dark">${d.status}</span></td>
      <td>${d.poDate || '-'}</td>
      <td><button class="btn btn-sm btn-outline-success" onclick="closePO('${doc.id}')">Received</button></td>
    </tr>`;
  });
  tbody.innerHTML = html;
}

window.closePO = async function(id) {
  if (confirm("Konfirmasi penerimaan barang kiriman supplier (Stok gudang otomatis bertambah)?")) {
    const poRef = doc(db, "purchaseorders", id);
    const poSnap = await getDoc(poRef);
    if (!poSnap.exists()) return;
    const poData = poSnap.data();
    
    for (let item of poData.items) {
      const pRef = doc(db, "parts", item.partId);
      const pSnap = await getDoc(pRef);
      if (pSnap.exists()) {
        let currentStock = parseInt(pSnap.data().stock) || 0;
        await updateDoc(pRef, { stock: currentStock + item.qty });
      }
    }
    await updateDoc(poRef, { status: "RECEIVED" });
    alert("✅ Barang kliring masuk logistik gudang!");
    logActivity('PO','Receive Goods','PO ID: ' + id);
  }
};

// ========================== MODULE ESTIMATION ==========================
function generateEstimationNumber() { const el = document.getElementById("estimationNumber"); if (el) el.value = "EST-" + Date.now().toString().slice(-6); }

function calculateEstimationValues() {
  const labor = parseFloat(document.getElementById("estimationLabor").value) || 0;
  const parts = parseFloat(document.getElementById("estimationParts").value) || 0;
  const disc = parseFloat(document.getElementById("estimationDiscount").value) || 0;
  const taxRate = parseFloat(document.getElementById("estimationTax").value) || 0;
  
  const sub = labor + parts - disc;
  document.getElementById("estimationGrandTotal").value = sub + (sub * taxRate / 100);
}
["estimationLabor","estimationParts","estimationDiscount","estimationTax"].forEach(id => {
  document.getElementById(id)?.addEventListener("input", calculateEstimationValues);
});

document.getElementById("btnSaveEstimation")?.addEventListener("click", async function() {
  const woSel = document.getElementById("estimationWO");
  if (!woSel.value) { alert("⚠️ Silakan tentukan target Work Order!"); return; }
  
  const data = {
    estNumber: document.getElementById("estimationNumber").value,
    estDate: document.getElementById("estimationDate").value,
    woId: woSel.value, woNumber: woSel.options[woSel.selectedIndex].dataset.wonumber,
    customerName: document.getElementById("estimationCustomer").value,
    laborCost: parseFloat(document.getElementById("estimationLabor").value) || 0,
    partsCost: parseFloat(document.getElementById("estimationParts").value) || 0,
    discount: parseFloat(document.getElementById("estimationDiscount").value) || 0,
    taxPercent: parseFloat(document.getElementById("estimationTax").value) || 11,
    grandTotal: parseFloat(document.getElementById("estimationGrandTotal").value) || 0,
    status: document.getElementById("estimationStatus").value,
    note: document.getElementById("estimationNote").value.trim(),
    createdAt: new Date().toISOString()
  };
  await addDoc(collection(db, "estimations"), data);
  alert("✅ Surat penawaran biaya estimasi resmi tersimpan!");
  generateEstimationNumber();
  logActivity('ESTIMATION','Generate Penawaran','No: ' + data.estNumber);
});

function renderEstimations(snap) {
  const tbody = document.getElementById("estimationTable");
  if (!tbody) return;
  if (snap.empty) { tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Belum ada list estimasi keluar.</td></tr>'; return; }
  let html = "";
  snap.forEach(doc => {
    const d = doc.data();
    html += `<tr>
      <td>${d.estNumber}</td>
      <td>${d.woNumber}</td>
      <td>${d.customerName}</td>
      <td>${formatRupiah(d.grandTotal)}</td>
      <td><span class="badge bg-dark border text-warning">${d.status}</span></td>
      <td>${d.estDate || '-'}</td>
      <td><button class="btn btn-sm btn-success py-0" onclick="updateEstStatus('${doc.id}','APPROVED')">Approve</button></td>
    </tr>`;
  });
  tbody.innerHTML = html;
}

window.updateEstStatus = async function(id, status) {
  await updateDoc(doc(db, "estimations", id), { status: status });
  alert("✅ Konfirmasi status lembar estimasi dikunci!");
};

// ========================== MODULE INVOICE ==========================
function generateInvoiceNumber() { const el = document.getElementById("invoiceNumber"); if (el) el.value = "INV-" + Date.now().toString().slice(-6); }

function calculateInvoiceValues() {
  const sub = parseFloat(document.getElementById("invoiceSubtotal").value) || 0;
  const disc = parseFloat(document.getElementById("invoiceDiscount").value) || 0;
  const taxRate = parseFloat(document.getElementById("invoiceTax").value) || 0;
  
  const net = sub - disc;
  document.getElementById("invoiceGrandTotal").value = net + (net * taxRate / 100);
}
["invoiceSubtotal","invoiceDiscount","invoiceTax"].forEach(id => {
  document.getElementById(id)?.addEventListener("input", calculateInvoiceValues);
});

document.getElementById("btnSaveInvoice")?.addEventListener("click", async function() {
  const woSel = document.getElementById("invoiceWO");
  if (!woSel.value) { alert("⚠️ Target referensi data WO wajib diisi!"); return; }
  
  const data = {
    invNumber: document.getElementById("invoiceNumber").value,
    invDate: document.getElementById("invoiceDate").value,
    woId: woSel.value, woNumber: woSel.options[woSel.selectedIndex].dataset.wonumber,
    customerName: document.getElementById("invoiceCustomer").value,
    subtotal: parseFloat(document.getElementById("invoiceSubtotal").value) || 0,
    discount: parseFloat(document.getElementById("invoiceDiscount").value) || 0,
    taxPercent: parseFloat(document.getElementById("invoiceTax").value) || 11,
    grandTotal: parseFloat(document.getElementById("invoiceGrandTotal").value) || 0,
    status: document.getElementById("invoiceStatus").value,
    paidAmount: 0,
    createdAt: new Date().toISOString()
  };
  await addDoc(collection(db, "invoices"), data);
  alert("✅ Billing Invoice Faktur Sukses Diaktivasi!");
  generateInvoiceNumber();
  logActivity('INVOICE','Create Invoice','No: ' + data.invNumber);
});

function renderInvoices(snap) {
  const tbody = document.getElementById("invoiceTable");
  if (!tbody) return;
  if (snap.empty) { tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Belum ada riwayat tagihan invoice.</td></tr>'; return; }
  let html = "", totalInv = 0, totalPaid = 0, unpaidCount = 0;
  snap.forEach(doc => {
    const d = doc.data();
    if (d.status !== "VOID") {
      totalInv += d.grandTotal || 0;
      totalPaid += d.paidAmount || 0;
      if (d.status === "UNPAID") unpaidCount++;
    }
    html += `<tr><td><span class="badge bg-dark text-warning">${d.invNumber}</span></td><td>${d.customerName}</td><td>${d.woNumber}</td><td>${formatRupiah(d.grandTotal)}</td><td><span class="badge bg-danger">${d.status}</span></td><td>${d.invDate || '-'}</td></tr>`;
  });
  tbody.innerHTML = html;
  
  document.getElementById("invoiceTotalLabel").innerText = formatRupiah(totalInv);
  document.getElementById("invoicePaidLabel").innerText = formatRupiah(totalPaid);
  document.getElementById("invoiceBalanceLabel").innerText = formatRupiah(totalInv - totalPaid);
  document.getElementById("cardInvoice").innerText = unpaidCount;
  
  document.getElementById("cardRevenueToday").innerText = formatRupiah(totalPaid);
  document.getElementById("cardRevenueMonth").innerText = formatRupiah(totalPaid);
  
  updateChartsVisual(snap);
}

function updateInvoiceDropdown(snap) {
  const sel = document.getElementById("paymentInvoice");
  if (!sel) return;
  const val = sel.value;
  sel.innerHTML = '<option value="">Pilih Dokumen Invoice</option>';
  snap.forEach(doc => {
    const d = doc.data();
    if (d.status === "PAID" || d.status === "VOID") return;
    const opt = document.createElement("option");
    opt.value = doc.id;
    opt.dataset.invnumber = d.invNumber;
    opt.dataset.custname = d.customerName;
    opt.dataset.sisa = d.grandTotal - (d.paidAmount || 0);
    opt.textContent = `${d.invNumber} - ${d.customerName} (Sisa Tagihan: ${formatRupiah(opt.dataset.sisa)})`;
    sel.appendChild(opt);
  });
  sel.value = val;
}

document.getElementById("paymentInvoice")?.addEventListener("change", function() {
  const target = document.getElementById("paymentCustomer");
  if (!target) return;
  if (!this.value) { target.value = ""; return; }
  const opt = this.options[this.selectedIndex];
  target.value = opt.dataset.custname;
  document.getElementById("paymentAmount").value = opt.dataset.sisa;
});

// ========================== MODULE CASHIER (PAYMENTS) ==========================
function generatePaymentNumber() { const el = document.getElementById("paymentNumber"); if (el) el.value = "PAY-" + Date.now().toString().slice(-6); }

document.getElementById("btnSavePayment")?.addEventListener("click", async function() {
  const invSel = document.getElementById("paymentInvoice");
  const amount = parseFloat(document.getElementById("paymentAmount").value) || 0;
  if (!invSel.value || amount <= 0) { alert("⚠️ Nominal setoran dana & target invoice wajib valid!"); return; }
  
  const data = {
    paymentNumber: document.getElementById("paymentNumber").value,
    paymentDate: document.getElementById("paymentDate").value,
    invoiceId: invSel.value, invoiceNumber: invSel.options[invSel.selectedIndex].dataset.invnumber,
    customerName: document.getElementById("paymentCustomer").value,
    method: document.getElementById("paymentMethod").value,
    amount: amount,
    reference: document.getElementById("paymentReference").value.trim(),
    cashier: document.getElementById("paymentCashier").value.trim(),
    createdAt: new Date().toISOString()
  };
  await addDoc(collection(db, "payments"), data);
  
  const invRef = doc(db, "invoices", invSel.value);
  const invSnap = await getDoc(invRef);
  if (invSnap.exists()) {
    let currentPaid = parseFloat(invSnap.data().paidAmount) || 0;
    let finalPaid = currentPaid + amount;
    let status = finalPaid >= parseFloat(invSnap.data().grandTotal) ? "PAID" : "PARTIAL";
    await updateDoc(invRef, { paidAmount: finalPaid, status: status });
  }
  
  alert("✅ Pembayaran Kliring Berhasil Divalidasi!");
  document.getElementById("paymentAmount").value = "";
  document.getElementById("paymentReference").value = "";
  generatePaymentNumber();
  logActivity('PAYMENT','Execute Payment','No: ' + data.paymentNumber);
});

function renderPayments(snap) {
  const tbody = document.getElementById("cashierTable");
  if (!tbody) return;
  if (snap.empty) { tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Belum ada kas masuk terpantau hari ini.</td></tr>'; return; }
  
  let html = "", c = 0, t = 0, q = 0, e = 0;
  snap.forEach(doc => {
    const d = doc.data();
    const method = d.method || "CASH";
    if (method === "CASH") c += d.amount;
    else if (method === "TRANSFER") t += d.amount;
    else if (method === "QRIS") q += d.amount;
    else if (method === "EDC") e += d.amount;
    
    html += `<tr><td><strong>${d.paymentNumber}</strong></td><td>${d.invoiceNumber}</td><td><span class="badge bg-success">${method}</span></td><td>${formatRupiah(d.amount)}</td><td>${d.paymentDate || '-'}</td><td><button class="btn btn-sm btn-outline-danger py-0" onclick="voidPayment('${doc.id}','${d.invoiceId}',${d.amount})">Void</button></td></tr>`;
  });
  tbody.innerHTML = html;
  
  document.getElementById("summaryCash").innerText = formatRupiah(c);
  document.getElementById("summaryTransfer").innerText = formatRupiah(t);
  document.getElementById("summaryQRIS").innerText = formatRupiah(q);
  document.getElementById("summaryEDC").innerText = formatRupiah(e);
}

window.voidPayment = async function(payId, invId, amount) {
  if (confirm("Apakah Anda yakin ingin membatalkan transaksi pembayaran ini (Void)?")) {
    await deleteDoc(doc(db, "payments", payId));
    const invRef = doc(db, "invoices", invId);
    const invSnap = await getDoc(invRef);
    if (invSnap.exists()) {
      let currentPaid = parseFloat(invSnap.data().paidAmount) || 0;
      let finalPaid = Math.max(0, currentPaid - amount);
      await updateDoc(invRef, { paidAmount: finalPaid, status: "UNPAID" });
    }
    alert("✅ Transaksi dianulir.");
    logActivity('PAYMENT','Void Transaction','ID: ' + payId);
  }
};

// ========================== AUDIT SYSTEM SECURITY LOGS ==========================
async function logActivity(module, action, detail) {
  const user = auth.currentUser;
  if (!user) return;
  try {
    const userDoc = await getDoc(doc(db, "users", user.uid));
    const uData = userDoc.exists() ? userDoc.data() : {};
    await addDoc(collection(db, "activitylogs"), {
      userName: uData.Name || "System Staff",
      userRole: uData.Role || "STAFF",
      module, action, detail,
      timestamp: new Date().toISOString()
    });
  } catch(err) { console.warn("Log activity error:", err); }
}

function renderActivityLogs(snap) {
  const tbody = document.getElementById("activityLogTable");
  if (!tbody) return;
  let html = "";
  snap.forEach(doc => {
    const d = doc.data();
    html += `<tr><td><small>${d.timestamp ? d.timestamp.substring(11,19) : '-'}</small></td><td>${d.userName}</td><td>${d.userRole}</td><td><span class="badge bg-secondary">${d.module}</span></td><td><strong>${d.action}</strong></td><td><span class="text-white-50">${d.detail}</span></td></tr>`;
  });
  tbody.innerHTML = html || '<tr><td colspan="6" class="text-center text-muted">Belum ada jejak aktivitas terdeteksi.</td></tr>';
}

// ========================== USER PROFILE SETTINGS ==========================
async function loadUserTable() {
  const table = document.getElementById("userTable");
  if (!table) return;
  try {
    const snap = await getDocs(collection(db, "users"));
    let html = "";
    snap.forEach(doc => {
      const d = doc.data();
      const isActive = d.status === "ACTIVE";
      html += `<tr>
        <td><strong>${d.Name || '-'}</strong></td>
        <td>${d.Email || '-'}</td>
        <td><span class="badge bg-dark border border-info text-info">${d.Role}</span></td>
        <td><span class="badge ${isActive ? 'bg-success':'bg-warning text-dark'}">${d.status || 'PENDING'}</span></td>
        <td><small>${d.lastLogin || '-'}</small></td>
        <td>${!isActive ? `<button class="btn btn-sm btn-success py-0" onclick="approveUser('${doc.id}')">ACC</button>` : '-'}</td>
      </tr>`;
    });
    table.innerHTML = html || '<tr><td colspan="6" class="text-center text-muted">Belum ada data user.</td></tr>';
  } catch(e) { table.innerHTML = `<tr><td colspan="6" class="text-center text-danger">Error: ${e.message}</td></tr>`; }
}

window.approveUser = async function(id) {
  if (confirm("Aktifkan perizinan login sistem untuk user ini?")) {
    await updateDoc(doc(db, "users", id), { status: "ACTIVE" });
    alert("✅ Hak perizinan akses akun berhasil dibuka!");
    loadUserTable();
  }
};

document.getElementById("btnAddUser")?.addEventListener("click", async function() {
  const name = document.getElementById("userName").value.trim();
  const email = document.getElementById("userEmail").value.trim();
  const password = document.getElementById("userPassword").value;
  if (!name || !email || !password) { alert("⚠️ Parameter pembuatan akun user wajib dipenuhi!"); return; }
  try {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await setDoc(doc(db, "users", cred.user.uid), {
      Name: name, Email: email, Role: document.getElementById("userRole").value,
      status: document.getElementById("userStatus").value, createdAt: new Date().toISOString()
    });
    alert("✅ Akun user karyawan internal sukses ditambahkan!");
    document.getElementById("userName").value = "";
    document.getElementById("userEmail").value = "";
    document.getElementById("userPassword").value = "";
    loadUserTable();
  } catch(err) { alert("❌ Gagal mendaftarkan user: " + err.message); }
});

document.getElementById("btnSaveSettings")?.addEventListener("click", function() {
  alert("✅ Corporate Core Profile AKA BMW Service Berhasil Disinkronisasi!");
});

// ========================== MODULE KNOWLEDGE: INTEGRASI ETK OFFLINE 3.2.20 ==========================
const ETK_SOURCES = {
  etkoffline: {
    name: 'BMW ETK Desktop Offline',
    url: '',
    urlPart: '',
    canIframe: false,
    info: '<strong>BMW ETK Offline App (v3.2.20)</strong> – Menggunakan database Transbase lokal laptop. Sistem akan menyalin sasis secara otomatis ke memori Windows Anda.'
  },
  realoem: {
    name: 'RealOEM',
    url: 'https://www.realoem.com/bmw/en/select?vin=',
    urlPart: 'https://www.realoem.com/bmw/en/part?id=',
    canIframe: true,
    info: '<strong>RealOEM</strong> – database terakhir 2019 (cocok untuk sasis lawas).'
  },
  bimmercat: {
    name: 'BimmerCat',
    url: 'https://bimmercat.com/bmw/vin/decoder/',
    urlPart: 'https://bimmercat.com/bmw/part/',
    canIframe: true,
    info: '<strong>BimmerCat</strong> – database terakhir 2019 (cocok untuk sasis lawas).'
  },
  bimmerrefs: {
    name: 'BimmerRefs',
    url: 'https://bimmerrefs.com/vin/',
    urlPart: 'https://bimmerrefs.com/part/',
    canIframe: false,
    info: '<strong>BimmerRefs</strong> – database update sampai G-series & model terbaru.'
  }
};

window.resetEtkForm = function() {
  ["etkVin","etkPartNumber"].forEach(id => { const el = document.getElementById(id); if (el) el.value = ""; });
  closeEtkResult();
};

window.closeEtkResult = function() {
  const container = document.getElementById("etkResultContainer"); if (container) container.style.display = "none";
  const iframe = document.getElementById("etkResultIframe"); if (iframe) iframe.src = "";
};

document.getElementById("btnEtkSearch")?.addEventListener("click", function() {
  let vin = document.getElementById("etkVin").value.trim().toUpperCase();
  const partNumber = document.getElementById("etkPartNumber").value.trim();
  const source = document.getElementById("etkSource").value;
  
  if (!vin && !partNumber) {
    alert("⚠️ Parameter kosong! Masukkan nomor VIN Sasis atau Part Number terlebih dahulu.");
    return;
  }
  
  if (vin) {
    const cleanedVin = vin.replace(/[^A-Z0-9]/g, '');
    if (cleanedVin.length !== 7 && cleanedVin.length !== 17) {
      alert("❌ Format VIN salah! Sasis BMW harus berjumlah 7 digit atau 17 digit.");
      return;
    }
    if (/[IOQ]/.test(cleanedVin)) {
      alert("❌ Karakter I, O, atau Q tidak valid dalam standarisasi sasis BMW.");
      return;
    }
    vin = cleanedVin;
    document.getElementById("etkVin").value = vin;
  }
  
  const sourceData = ETK_SOURCES[source];
  if (!sourceData) return;
  
  // LOGIKA UTAMA SINKRONISASI COPIER UNTUK APLIKASI ETK LAPTOP
  if (source === 'etkoffline') {
    const textToCopy = vin ? vin : partNumber;
    const hiddenTextArea = document.createElement("textarea");
    hiddenTextArea.value = textToCopy;
    hiddenTextArea.style.position = "fixed";
    document.body.appendChild(hiddenTextArea);
    hiddenTextArea.select();
    
    try {
      document.execCommand("copy");
      alert(`📋 AUTOMATION SUCCESS!\n\nNomor sasis/part [ ${textToCopy} ] telah disalin otomatis ke Windows Clipboard.\n\nLangkah Mekanik:\n1. Buka aplikasi BMW ETK di laptop.\n2. Klik kotak input VIN/Sasis.\n3. Tekan tombol kombinasi Ctrl + V lalu Enter.`);
    } catch (err) {
      alert("❌ Gagal menyalin otomatis, silakan salin manual.");
    }
    
    document.body.removeChild(hiddenTextArea);
    closeEtkResult();
    return;
  }
  
  let searchUrl = "";
  if (vin) {
    searchUrl = sourceData.url + vin;
  } else if (partNumber) {
    searchUrl = sourceData.urlPart + partNumber;
  }
  
  if (!sourceData.canIframe) {
    window.open(searchUrl, '_blank');
  } else {
    const container = document.getElementById("etkResultContainer");
    const iframe = document.getElementById("etkResultIframe");
    const title = document.getElementById("etkResultTitle");
    
    if (container && iframe) {
      container.style.display = "block";
      iframe.src = searchUrl;
      if (title) title.innerText = vin ? "Hasil Sasis: " + vin : "Hasil Part: " + partNumber;
      container.scrollIntoView({ behavior: "smooth" });
    }
  }
});

function updateWACustomerDropdown(snap) {
  const sel = document.getElementById("waCustomer"); if (!sel) return;
  const val = sel.value; sel.innerHTML = '<option value="">Pilih Customer</option>';
  snap.forEach(doc => {
    const d = doc.data();
    if(d.phone) {
      const opt = document.createElement("option");
      opt.value = d.phone; opt.textContent = `${d.name} (${d.phone})`;
      sel.appendChild(opt);
    }
  });
  sel.value = val;
}

function renderWACustomerList(snap) {
  const tbody = document.getElementById("waCustomerList"); if (!tbody) return;
  let html = "";
  snap.forEach(doc => {
    const d = doc.data();
    if(d.phone) {
      let cleanNum = d.phone.replace(/[^0-9]/g, '');
      if (cleanNum.startsWith('0')) cleanNum = '62' + cleanNum.substring(1);
      const link = `https://wa.me/${cleanNum}`;
      html += `<tr><td>${d.name}</td><td>${d.phone}</td><td><a href="${link}" target="_blank" class="whatsapp-btn"><i class="fa-brands fa-whatsapp"></i> Chat Direct</a></td></tr>`;
    }
  });
  tbody.innerHTML = html || '<tr><td colspan="3" class="text-center text-muted">Tidak ada kontak nomor HP.</td></tr>';
}

document.getElementById("btnWaSend")?.addEventListener("click", function() {
  const phone = document.getElementById("waCustomer").value;
  const template = document.getElementById("waQuickMessage").value;
  const custom = document.getElementById("waCustomMessage").value.trim();
  const text = custom || template;
  if (!phone || !text) { alert("⚠️ Tentukan customer & isi pesan teks!"); return; }
  
  let cleanNum = phone.replace(/[^0-9]/g, '');
  if (cleanNum.startsWith('0')) cleanNum = '62' + cleanNum.substring(1);
  window.open(`https://wa.me/${cleanNum}?text=${encodeURIComponent(text)}`, '_blank');
});

// ========================== CORE VISUAL DASHBOARD CHARTS ENGINE ==========================
function updateChartsVisual(invoiceSnap) {
  const ctxRevenue = document.getElementById("revenueChart");
  const ctxStatus = document.getElementById("woStatusChart");
  
  if (ctxRevenue) {
    const dataValues = [12000000, 19000000, 32000000, 5000000, 24000000, 45000000];
    let liveCollected = 0;
    invoiceSnap.forEach(doc => { if(doc.data().status === "PAID") liveCollected += doc.data().grandTotal || 0; });
    dataValues[dataValues.length - 1] = liveCollected;
    
    if (revenueChartInstance) revenueChartInstance.destroy();
    revenueChartInstance = new Chart(ctxRevenue.getContext("2d"), {
      type: "line",
      data: {
        labels: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun"],
        datasets: [{ label: "Pendapatan Bersih Terkliring", data: dataValues, borderColor: "#06d6a0", backgroundColor: "rgba(6,214,160,0.08)", tension: 0.2, fill: true }]
      },
      options: { responsive: true, plugins: { legend: { labels: { color: "#fff" } } } }
    });
  }
  
  if (ctxStatus) {
    if (woStatusChartInstance) woStatusChartInstance.destroy();
    woStatusChartInstance = new Chart(ctxStatus.getContext("2d"), {
      type: "doughnut",
      data: {
        labels: ["CHECK_IN", "DIAGNOSA", "PROSES", "SELESAI"],
        datasets: [{ data: [3, 2, 5, 4], backgroundColor: ["#8a9bb5", "#ffb703", "#00b4d8", "#06d6a0"] }]
      },
      options: { responsive: true, plugins: { legend: { labels: { color: "#fff" } } } }
    });
  }
}

console.log("🚀 AKA BMW ISGM Core Terminal Application Engine Loaded successfully.");
